/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AddQuizPackage;

import java.util.ArrayList;

/**
 *
 * @author Michael
 */
public class AddQuiz {
    private final ArrayList<Integer> numbers;
    private final ArrayList<String> questions;
    private final ArrayList<String> results;
    private final int NUMBER_OF_QUESTIONS = 10;
    private int count;

    /**
     * Creates a new instance of QuizBean
     */
    public AddQuiz() {
        numbers = new ArrayList<>(20);
        questions = new ArrayList<>(10);
        results = new ArrayList<>(11);
        count = 0;
    }
    
    public String newQuestions(){
        count = 0;
        numbers.clear();
        questions.clear();
        results.clear();
        
        int number1;
        int number2;
        
        for(int index = 0; index < NUMBER_OF_QUESTIONS; index++){
            number1 = (int)(Math.random() * 100);
            number2 = (int)(Math.random() * 100);
            
            numbers.add(number1);
            numbers.add(number2);
            
            questions.add(String.format("%10s", number1 + " + " + number2 + " = "));
        }
        
        return "location.reload()";
    }
    
    public String getQuestion(int index){
        return questions.get(index);
    }
    
    public void displayResults(String[] answers){
        StringBuilder builder = new StringBuilder();
        int number1;
        int number2;
        
        for (int index = 0; index < NUMBER_OF_QUESTIONS; index++){
            number1 = numbers.get(index * 2);
            number2 = numbers.get(index * 2 + 1);
            
            builder.append(String.format("%-13s", questions.get(index) + answers[index]));
            
            if (number1 + number2 == Integer.parseInt(answers[index])){
                builder.append(" is Correct!</br>");
                count++;
            }
            else{
                builder.append(" is Incorrect!</br>");
            }
            results.add(builder.toString());
            builder.setLength(0);
        }
        
        results.add("You got " + count + " out of " + NUMBER_OF_QUESTIONS + " correct!</br>");
    }
    
    public ArrayList<String> getResults(){
        return results;
    }
}
