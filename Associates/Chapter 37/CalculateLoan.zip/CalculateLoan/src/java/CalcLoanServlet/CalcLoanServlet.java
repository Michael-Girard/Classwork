/*
Program Name: Loan Calculator
Program Purpose: Calculate the monthly payment, total payment, and output a payment schedule for
   a specific loan amount, payment duration, and annual interest rate.
Author: Michael Girard
Date Last Modified: March 24, 2015
Program created using the comprehensive 10th edition textbook, JDK 8u31, and NetBeans 8.0.2

Note: Instead of stopping where the images in the book showed, I also converted the payment schedule portion
    of "LoanAmortizationSchedule.java", an assignment we did for Chapter 5 almost a year ago.
*/
package CalcLoanServlet;

import java.util.*;
import java.text.NumberFormat;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Michael
 */
public class CalcLoanServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CalcLoanServlet</title>");
            out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"CalcLoanCSS.css\">");
            out.println("</head>");
            out.println("<body>");
            out.println("<a id=\"top\"></a>");
            out.println("<input type=\"button\" onclick=\"window.location.href='index.html'\" value=\"<- Back\"/>");
            out.println("<br><br>");
            //boolean displaySchedule = request.getParameter("displaySchedule") != null;
            new Loan.Loan(Double.valueOf(request.getParameter("loanAmount")), Double.valueOf(request.getParameter("annualInterestRate")), 
                    Integer.valueOf(request.getParameter("numberOfYears")), out).displayLoanInformation(request.getParameter("displaySchedule") != null);
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
