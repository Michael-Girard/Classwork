/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Loan;

import java.text.NumberFormat;
import java.util.*;
import java.io.*;

/**
 *
 * @author Michael
 */
public class Loan {
    private final int MONTHS_IN_A_YEAR = 12;
    private double loanAmount;
    private double annualInterestRate;
    private double monthlyInterestRate;
    private double monthlyPayment;
    private int numberOfYears;
    private int numberOfMonths;
    private PrintWriter out;
    
    public Loan(double loanAmount, double annualInterestRate, int numberOfYears, PrintWriter out){
        this.loanAmount = loanAmount;
        this.annualInterestRate = annualInterestRate / 100;
        this.monthlyInterestRate = this.annualInterestRate / MONTHS_IN_A_YEAR;
        this.numberOfYears = numberOfYears;
        this.numberOfMonths = numberOfYears * MONTHS_IN_A_YEAR;
        this.monthlyPayment = loanAmount * monthlyInterestRate / (1 - 1 / Math.pow(1 + monthlyInterestRate, numberOfMonths));
        this.out = out;
    }
    
    public void displayLoanInformation(boolean displaySchedule){
        double balance = loanAmount;
        double totalPayment = loanAmount;
        double interest;
        double principal;
        NumberFormat numFormat = NumberFormat.getCurrencyInstance(Locale.US);
        String header = String.format("<p>%-20s%-20s%-20s%-20s</p>", "Payment#", "Interest", "Principal", "Balance");
        String separator = "<p>------------------------------------------------------------------------------------</p>";
        StringBuilder builder = new StringBuilder();
        
        out.println("<p>For a " + numberOfYears + "-year, " +
                numFormat.format(loanAmount) + " loan with an annual interest rate of " + 
                annualInterestRate * 100 + "%...");
        out.println("<p class=\"red\">Your monthly payment will be " + numFormat.format(monthlyPayment) + ".</p>");
        
        if(displaySchedule){
            builder.append(header);
            builder.append(separator);
        }
        
        for (int index = 1; index <= numberOfMonths; index++){
            interest = monthlyInterestRate * balance;
            totalPayment += interest;
            
            if(index == numberOfMonths){
                principal = balance;
                balance = 0;
            }
            else{
                principal = monthlyPayment - interest;
                balance -= principal;
            }
            
            if(displaySchedule){
                builder.append(String.format("<p>%-25d%-18s%-18s%-18s</p>", index, numFormat.format(interest), numFormat.format(principal), numFormat.format(balance)));
                builder.append(separator);
            
                if(index % 30 == 0){
                    builder.append("<input type=\"button\" class=\"toTop\" onclick=\"window.location.href='#top'\" value=\"Back to Top\"/>");
                    
                    if(index != numberOfMonths){
                        builder.append(separator);
                        builder.append(header);
                        builder.append(separator);
                    }
                }
            }
        }
        
        out.println("<p class=\"red\">In total, you will pay " + numFormat.format(totalPayment) + ".</p>");
        
        if(displaySchedule){
            out.println("<br>");
            out.println("<p>Your payment schedule is as follows...</p>");
            out.println("<br>");
            out.println("<div class=\"schedule\">");
            out.println(builder.toString());
            out.println("</div>");
        }
    }
}
