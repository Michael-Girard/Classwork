/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter39;

import javax.jws.WebService;
import javax.jws.WebMethod;
import com.sun.xml.ws.developer.servlet.HttpSessionScope;

/**
 *
 * @author Michael
 */
@HttpSessionScope
@WebService(serviceName = "VisitCountService")
public class VisitCountService {

    /**
     * This is a sample web service operation
     */
    
    private int invokeCount = 0;
    
    @WebMethod(operationName = "getCount")
    public int getCount() {
        invokeCount++;
        return invokeCount;
    }
}
