/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visitcountserviceclient;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.geometry.Insets;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import myWebService.VisitCountService_Service;
import myWebService.VisitCountService;

/**
 *
 * @author Michael
 */
public class VisitCountServiceClient extends Application{

    /**
     * @param args the command line arguments
     */
    
    private VisitCountService_Service visitCountService = new VisitCountService_Service();
    private VisitCountService proxy = visitCountService.getVisitCountServicePort();
    
    public static void main(String[] args) {
        Application.launch();
    }
    
    @Override
    public void start(Stage primaryStage){
        //Create layout and controls
        GridPane pane = new GridPane();
        Label tfLabel = new Label("    getCount()\ninvocation count:");
        TextField serviceResponse = new TextField();
        Button btGetCount = new Button("   Invoke\ngetCount()");
        
        //Layout Styling
        pane.setPadding(new Insets(8,8,8,8));
        pane.setVgap(8);
        pane.getColumnConstraints().addAll(new ColumnConstraints(50), new ColumnConstraints(50),
                new ColumnConstraints(100));
        
        //Label Styling
        GridPane.setRowSpan(tfLabel, 2);
        GridPane.setColumnSpan(tfLabel, 2);
        GridPane.setHalignment(tfLabel, HPos.CENTER);
        
        //Button Styling
        GridPane.setRowSpan(btGetCount, 3);
        GridPane.setHalignment(btGetCount, HPos.CENTER);
        btGetCount.setMinWidth(80);
        
        //TextField Styling
        GridPane.setRowSpan(serviceResponse, 2);
        GridPane.setColumnSpan(serviceResponse, 2);
        GridPane.setHalignment(serviceResponse, HPos.CENTER);
        GridPane.setValignment(serviceResponse, VPos.CENTER);
        serviceResponse.setEditable(false);
        serviceResponse.setMaxWidth(50);
        
        //Place the controls on the layout
        pane.add(btGetCount, 1, 0);
        pane.add(tfLabel, 0, 3);
        pane.add(serviceResponse, 1, 3);
        
        //Create a scene, etc.
        Scene scene = new Scene(pane, 170, 100);
        primaryStage.setTitle("Count");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        /*
          Because VisitCountService is set to use @HttpSessionScope,
          the count will never rise above 1.
        */
        btGetCount.setOnAction(e-> {
            serviceResponse.setText(String.valueOf(proxy.getCount()));
        });
    }
}
