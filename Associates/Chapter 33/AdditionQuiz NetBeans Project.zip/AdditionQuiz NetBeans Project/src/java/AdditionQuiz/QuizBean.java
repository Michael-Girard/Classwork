/*
Program Name: Addition Quiz
Program Purpose: Create a program to give an addition quiz using Java and XML.
Author: Michael Girard
Date Last Modified: March 13, 2015.
Program created using the comprehensive 10th edition textbook, JDK 8u31, and NetBeans 8.0.2.

Note: I had no knowledge about XML, so this program will work, but probably not be very efficient.
*/

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AdditionQuiz;

import javax.inject.Named;
import javax.faces.bean.ManagedBean;
import javax.enterprise.context.SessionScoped;
import java.util.*;
import java.io.Serializable;

/**
 *
 * @author Michael
 */
@Named(value = "quizBean")
@ManagedBean
@SessionScoped
public class QuizBean implements Serializable{
    private final ArrayList<Integer> numbers;
    private final ArrayList<String> questions;
    private ArrayList<String> answerList;
    private final int NUMBER_OF_QUESTIONS = 10;
    private int count;

    /**
     * Creates a new instance of QuizBean
     */
    public QuizBean() {
        numbers = new ArrayList<>(20);
        questions = new ArrayList<>(10);
        answerList = new ArrayList<>(10);
        count = 0;
        this.newQuestions(); //Initialize the bean with a set of questions
    }
    
    public String getQuestion(int index){
        return questions.get(index);
    }
    
    //Aggregates the answers from the text fields into a list to use when getting the test results
    //When finished, proceed to the results.xhtml page
    public String prepareResults(String a1, String a2, String a3, String a4, String a5, String a6,
            String a7, String a8, String a9, String a10){
        answerList.addAll(Arrays.asList(new String[]{a1, a2, a3, a4, a5, a6, a7, a8, a9
                , a10}));
        
        return "results";
    }
    
    //getResult is called 10 times, which both gets the test results and empties the lists for the next quiz
    public String getResult(){
        String currentAnswer = answerList.remove(0);
        
        if (numbers.remove(0) + numbers.remove(0) == Integer.parseInt(currentAnswer)){
            count++;
            return questions.remove(0) + currentAnswer + " Correct!";
        }
        else{
            return questions.remove(0) + currentAnswer + " Wrong!";
        }
    }
    
    public String gradeMe(){
        String results = "You got " + count + " out of " + NUMBER_OF_QUESTIONS + " right, earning " + ((count * 1.0/NUMBER_OF_QUESTIONS) * 100) + "%!";
        count = 0;
        return results;
    }
    
    //Get a fresh batch of questions and return to the index.xhtml page
    public String newQuiz(){
        newQuestions();
        return "index";
    }
    
    //Prepare new test questions
    public void newQuestions(){
        while(questions.size() != 10){
            int number1 = (int)(Math.random() * 100);
            int number2 = (int)(Math.random() * 100);
            numbers.add(number1);
            numbers.add(number2);
            questions.add(number1 + " + " + number2 + " = ");
        }
    }
}
